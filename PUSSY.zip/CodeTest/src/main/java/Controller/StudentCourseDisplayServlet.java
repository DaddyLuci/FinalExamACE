package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.CourseDAO;
import DAO.StudentDAO;
import DAO.UserDAO;
import DTO.CourseResponseDTO;
import DTO.StudentRequestDTO;
import DTO.StudentResponseDTO;
import DTO.UserRequestDTO;
import DTO.UserResponseDTO;

/**
 * Servlet implementation class StudentCourseDisplayServlet
 */
@WebServlet("/StudentCourseDisplayServlet")
public class StudentCourseDisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentCourseDisplayServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentRequestDTO dto = new StudentRequestDTO();
		dto.setStudentid(request.getParameter("studentid"));
		StudentDAO dao1 = new StudentDAO();
		StudentResponseDTO res = dao1.selectOne(dto);
		request.setAttribute("res", res);

		
		
		CourseDAO dao=new CourseDAO();
		ArrayList<CourseResponseDTO> list=dao.selectAll();
	
		request.setAttribute("courselist",list);
		request.getRequestDispatcher("STU002.jsp").forward(request,response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
