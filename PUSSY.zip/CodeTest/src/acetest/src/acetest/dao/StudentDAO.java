package acetest.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import acetest.dto.StudentRequestDTO;
import acetest.dto.StudentResponseDTO;

public class StudentDAO {
	public static Connection con=null;
	static {
		con=MyConnection.getConnection();
	}

	public void insertData(StudentRequestDTO dto) {
		String sql="INSERT INTO student(name,dob,gender,phone,education,course)"+
				"values(?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getStudentName());
			ps.setString(2,dto.getStudentBirthday());
			ps.setString(3,dto.getStudentGender());
			ps.setString(4,dto.getStudentPhone());
			ps.setString(5,dto.getStudentEducation());
			ps.setString(6,dto.getStudentAttend());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void updateData(StudentRequestDTO dto) {
		String sql="UPDATE student SET name=?,dob=?,gender=?,phone=?,education=?,course=?"+
					"WHERE id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,dto.getStudentName());
			ps.setString(2,dto.getStudentBirthday());
			ps.setString(3,dto.getStudentGender());
			ps.setString(4,dto.getStudentPhone());
			ps.setString(5,dto.getStudentEducation());
			ps.setString(6,dto.getStudentAttend());
			ps.setString(7,dto.getStudentId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void deleteData(StudentRequestDTO dto) {
		String sql="DELETE FROM student WHERE id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dto.getStudentId());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<StudentResponseDTO> selectAll(){
		ArrayList<StudentResponseDTO> list=new ArrayList<>();
		String sql="SELECT student.id,student.name,courses.name\r\n" + 
				" from student inner join courses on student.id=courses.id;";
		PreparedStatement ps;
		try {
			ps = con.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				StudentResponseDTO res=new StudentResponseDTO();
				res.setStudentId(rs.getString("id"));
				res.setStudentName(rs.getString("name"));
				//res.setStudentBirthday(rs.getString("student_birthday"));
				//res.setStudentGender(rs.getString("student_gender"));
				//res.setStudentPhone(rs.getString("student_phone"));
				//res.setStudentEducation(rs.getString("student_education"));
				res.setStudentAttend(rs.getString("name"));
				list.add(res);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public StudentResponseDTO selectOne(StudentRequestDTO dto) {
		StudentResponseDTO res=new StudentResponseDTO();
		String sql="SELECT * FROM student WHERE id=?";
		try {
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, dto.getStudentId());
			ResultSet rs=ps.executeQuery();
			while (rs.next()) {
				res.setStudentName(rs.getString("student_name"));
				res.setStudentBirthday(rs.getString("student_birthday"));
				res.setStudentGender(rs.getString("student_gender"));
				res.setStudentPhone(rs.getString("student_phone"));
				res.setStudentEducation(rs.getString("student_education"));
				res.setStudentAttend(rs.getString("student_attend"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	
}
